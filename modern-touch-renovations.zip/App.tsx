
import React, { useEffect, useState } from 'react';
import { 
  Home, 
  Building2, 
  Settings, 
  CheckCircle2, 
  ArrowRight, 
  ShieldCheck, 
  Award, 
  HardHat, 
  Phone, 
  Mail, 
  MapPin,
  Menu,
  X
} from 'lucide-react';

// --- Utility Components ---

const RevealOnScroll: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isVisible, setIsVisible] = useState(false);
  const domRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => setIsVisible(entry.isIntersecting));
    }, { threshold: 0.1 });
    
    if (domRef.current) observer.observe(domRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={domRef}
      className={`transition-all duration-1000 transform ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
    >
      {children}
    </div>
  );
};

const BorderBeamButton: React.FC<{ 
  children: React.ReactNode; 
  className?: string;
  onClick?: () => void;
}> = ({ children, className = "", onClick }) => (
  <div className={`border-beam-container group ${className}`}>
    <div className="border-beam"></div>
    <button 
      onClick={onClick}
      className="relative z-10 w-full bg-brand-accent text-brand-black font-bold py-4 px-10 rounded-xl flex items-center justify-center gap-2 hover:bg-brand-accentLight transition-all duration-300 uppercase tracking-widest text-sm"
    >
      {children}
    </button>
  </div>
);

// --- Sections ---

const Logo = ({ className = "w-12 h-12" }: { className?: string }) => (
  /* The logo image provided in the prompt is a gold interlocking geometric octagon/hexagon */
  <img 
    src="https://moderntouchrenovationsinc.ca/wp-content/uploads/2020/02/MT-Logo-Gold-300x300.png" 
    alt="Modern Touch Renovations Logo" 
    className={`${className} object-contain`}
    onError={(e) => {
      // Fallback in case of link issues
      e.currentTarget.style.display = 'none';
    }}
  />
);

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 ${
      isScrolled ? 'py-4 bg-brand-black/90 backdrop-blur-md border-b border-white/5' : 'py-8 bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-4 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
          <Logo className="w-10 h-10 md:w-14 md:h-14 group-hover:scale-105 transition-transform duration-500" />
          <div className="flex flex-col">
            <span className="font-extrabold text-xl tracking-tighter uppercase leading-none">
              Modern Touch <span className="text-brand-accent">Renovations</span>
            </span>
            <span className="text-[10px] tracking-[0.2em] text-brand-accent uppercase font-medium mt-1">
              Project Management Done Right
            </span>
          </div>
        </div>
        
        <div className="hidden md:flex items-center gap-10 text-[11px] font-bold uppercase tracking-[0.15em] text-white/60">
          <a href="#services" className="hover:text-brand-accent transition-colors">Services</a>
          <a href="#why-us" className="hover:text-brand-accent transition-colors">Standards</a>
          <a href="#contact" className="hover:text-brand-accent transition-colors">Contact</a>
          <a 
            href="#estimate" 
            className="border border-brand-accent/30 hover:border-brand-accent hover:text-brand-accent text-white px-6 py-2.5 rounded-sm transition-all bg-white/5"
          >
            Start Project
          </a>
        </div>

        <button 
          className="md:hidden text-brand-accent"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="absolute top-full left-0 w-full bg-brand-black/95 backdrop-blur-xl border-b border-brand-accent/20 p-8 flex flex-col gap-6 animate-in fade-in slide-in-from-top-4 md:hidden">
          <a href="#services" className="text-lg uppercase tracking-widest font-bold" onClick={() => setMobileMenuOpen(false)}>Services</a>
          <a href="#why-us" className="text-lg uppercase tracking-widest font-bold" onClick={() => setMobileMenuOpen(false)}>Standards</a>
          <a href="#contact" className="text-lg uppercase tracking-widest font-bold" onClick={() => setMobileMenuOpen(false)}>Contact</a>
          <a href="#estimate" className="text-brand-accent text-lg uppercase tracking-widest font-bold" onClick={() => setMobileMenuOpen(false)}>Start Project</a>
        </div>
      )}
    </nav>
  );
};

const Hero = () => (
  <section className="relative min-h-[95vh] flex items-center justify-center overflow-hidden pt-24 px-6">
    <div className="absolute inset-0 z-0">
      <img 
        src="https://moderntouchrenovationsinc.ca/wp-content/uploads/2020/02/Commercial-Mobile-e1593128568959.jpg" 
        className="w-full h-full object-cover opacity-40 mix-blend-luminosity scale-105" 
        alt="High-end Renovation Project"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-brand-black via-brand-black/60 to-brand-black" />
      <div className="absolute inset-0 bg-gradient-to-r from-brand-black via-transparent to-brand-black" />
      <div className="bg-drift absolute top-1/3 -left-1/4 w-[700px] h-[700px] bg-brand-accent/5 rounded-full" />
    </div>

    <div className="relative z-10 max-w-6xl mx-auto text-center">
      <RevealOnScroll>
        <div className="flex items-center justify-center gap-4 mb-8">
            <div className="h-[1px] w-8 md:w-16 bg-brand-accent/50" />
            <span className="text-[11px] md:text-sm font-bold tracking-[0.3em] uppercase text-brand-accent">
                Southern Ontario's Elite Renovation Firm
            </span>
            <div className="h-[1px] w-8 md:w-16 bg-brand-accent/50" />
        </div>
        
        <h1 className="text-4xl md:text-7xl font-black tracking-tighter leading-[1.05] mb-10 text-white uppercase italic">
          Renovations Held <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-b from-brand-accent via-brand-accentLight to-brand-accent">
            To A Higher Standard.
          </span>
        </h1>
        
        <div className="max-w-3xl mx-auto mb-14">
            <p className="text-lg md:text-2xl text-white/70 leading-relaxed font-light mb-6">
                Led by <span className="text-white font-semibold">Richard Falle</span>, a veteran project manager trusted by the Mike Holmes and Brian Baeumler communities.
            </p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
          <BorderBeamButton className="w-full sm:w-auto" onClick={() => document.getElementById('estimate')?.scrollIntoView({ behavior: 'smooth' })}>
            Start Your Project <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </BorderBeamButton>
          <div className="flex items-center gap-3 text-white/40 text-[10px] uppercase tracking-widest font-bold">
            <CheckCircle2 className="w-5 h-5 text-brand-accent" />
            <span>Project Management Done Right</span>
          </div>
        </div>
      </RevealOnScroll>
    </div>

    <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-40">
      <div className="w-[1px] h-16 bg-gradient-to-b from-brand-accent to-transparent" />
    </div>
  </section>
);

const SocialProof = () => (
  <section className="py-16 border-y border-brand-accent/10 bg-brand-accent/[0.02]">
    <div className="max-w-7xl mx-auto px-6">
      <div className="flex flex-wrap justify-center items-center gap-10 md:gap-24 opacity-60 hover:opacity-100 transition-all duration-700">
        <div className="flex flex-col items-center gap-2 text-center">
          <ShieldCheck className="w-10 h-10 text-brand-accent" />
          <span className="font-black text-xs tracking-widest uppercase">SAFETY CERTIFIED</span>
        </div>
        <div className="flex flex-col items-center gap-2 text-center">
          <Award className="w-10 h-10 text-brand-accent" />
          <span className="font-black text-xs tracking-widest uppercase">HOLMES APPROVED</span>
        </div>
        <div className="flex flex-col items-center gap-2 text-center">
          <HardHat className="w-10 h-10 text-brand-accent" />
          <span className="font-black text-xs tracking-widest uppercase">WSIB COMPLIANT</span>
        </div>
        <div className="flex flex-col items-center gap-2 text-center">
          <Building2 className="w-10 h-10 text-brand-accent" />
          <span className="font-black text-xs tracking-widest uppercase">MASTER BUILDER</span>
        </div>
      </div>
    </div>
  </section>
);

const ValueProp = () => (
  <section id="why-us" className="py-32 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-2 gap-24 items-center">
        <RevealOnScroll>
          <span className="text-brand-accent font-bold tracking-[0.4em] uppercase text-xs mb-6 block">Our Commitment</span>
          <h2 className="text-4xl md:text-7xl font-extrabold tracking-tighter mb-10 uppercase italic leading-none">
            Precision <br /> 
            <span className="text-brand-accent">Without Compromise.</span>
          </h2>
          <div className="space-y-12">
            <div className="flex gap-8 group">
              <div className="flex-shrink-0 w-16 h-16 border border-brand-accent/20 group-hover:border-brand-accent/100 transition-colors flex items-center justify-center text-brand-accent rotate-45">
                <Settings className="w-8 h-8 -rotate-45" />
              </div>
              <div>
                <h4 className="text-xl font-black uppercase tracking-widest mb-3">Licensed Excellence</h4>
                <p className="text-white/50 leading-relaxed font-light">Every lead contractor is a licensed red-seal professional. We don't just "do renovations"; we engineer spaces to exceed the Ontario Building Code.</p>
              </div>
            </div>
            <div className="flex gap-8 group">
              <div className="flex-shrink-0 w-16 h-16 border border-brand-accent/20 group-hover:border-brand-accent/100 transition-colors flex items-center justify-center text-brand-accent rotate-45">
                <CheckCircle2 className="w-8 h-8 -rotate-45" />
              </div>
              <div>
                <h4 className="text-xl font-black uppercase tracking-widest mb-3">The Accurate Guarantee</h4>
                <p className="text-white/50 leading-relaxed font-light">Our estimates are final. Utilizing proprietary project management workflows, we eliminate "budget creep" before the first hammer swings.</p>
              </div>
            </div>
          </div>
        </RevealOnScroll>
        
        <RevealOnScroll>
          <div className="relative group">
            <div className="absolute -inset-10 bg-brand-accent/5 rounded-full blur-[100px] group-hover:bg-brand-accent/10 transition-all" />
            <div className="relative aspect-[4/5] overflow-hidden border border-brand-accent/20 shadow-[0_0_80px_rgba(197,160,89,0.1)]">
              <img 
                src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1200&auto=format&fit=crop" 
                alt="Modern High-End Interior" 
                className="w-full h-full object-cover grayscale brightness-75 group-hover:grayscale-0 group-hover:scale-110 transition-all duration-1000"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-brand-black/20 to-transparent" />
              <div className="absolute bottom-12 left-12 right-12">
                <p className="text-4xl font-black uppercase italic tracking-tighter mb-2">The Result</p>
                <div className="flex items-center gap-6">
                  <div className="h-[2px] w-16 bg-brand-accent" />
                  <p className="text-lg font-bold tracking-widest text-brand-accent uppercase">Peace of Mind</p>
                </div>
              </div>
            </div>
          </div>
        </RevealOnScroll>
      </div>
    </div>
  </section>
);

const Services = () => {
  const services = [
    {
      title: "Residential",
      icon: <Home className="w-10 h-10" />,
      desc: "Architectural transformations and luxury basement developments that redefine home.",
      image: "https://images.unsplash.com/photo-1613545325278-f24b0cae1224?q=80&w=800"
    },
    {
      title: "Commercial",
      icon: <Building2 className="w-10 h-10" />,
      desc: "Specialized retail and professional workspace build-outs optimized for performance.",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=800"
    },
    {
      title: "Mechanicals",
      icon: <Settings className="w-10 h-10" />,
      desc: "Infrastructure upgrades: HVAC, Electrical, and high-precision plumbing systems.",
      image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?q=80&w=800"
    }
  ];

  return (
    <section id="services" className="py-32 px-6 bg-white/[0.02]">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end gap-10 mb-20">
          <RevealOnScroll>
            <span className="text-brand-accent font-bold tracking-[0.4em] uppercase text-xs mb-6 block">Specializations</span>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase leading-none italic">
              Elite Engineering <br />
              <span className="text-brand-accent">For Modern Living.</span>
            </h2>
          </RevealOnScroll>
          <RevealOnScroll>
            <p className="text-white/40 max-w-sm text-lg leading-relaxed font-light">
                Tailored solutions for complex renovation projects across Southern Ontario.
            </p>
          </RevealOnScroll>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, i) => (
            <RevealOnScroll key={i}>
              <div className="group relative bg-brand-black border border-white/10 p-10 hover:border-brand-accent transition-all duration-700 overflow-hidden h-full flex flex-col">
                <div className="absolute top-0 right-0 w-48 h-48 bg-brand-accent/5 blur-[80px] rounded-full group-hover:bg-brand-accent/20 transition-all duration-700" />
                
                <div className="relative z-10 flex-grow">
                  <div className="mb-10 text-brand-accent">
                    {service.icon}
                  </div>
                  <h3 className="text-2xl font-black uppercase tracking-widest mb-6 italic">{service.title}</h3>
                  <p className="text-white/50 leading-relaxed font-light mb-10 min-h-[80px]">
                    {service.desc}
                  </p>
                </div>
                
                <div className="aspect-[16/10] overflow-hidden border border-white/5 grayscale group-hover:grayscale-0 transition-all duration-1000">
                  <img src={service.image} alt={service.title} className="w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-1000" />
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => (
  <section id="contact" className="py-32 px-6 relative bg-brand-black">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-2 gap-24">
        <RevealOnScroll>
          <span className="text-brand-accent font-bold tracking-[0.4em] uppercase text-xs mb-6 block">Inquiry</span>
          <h2 className="text-4xl md:text-7xl font-black tracking-tighter mb-12 uppercase italic leading-none">
            Invest in <br />
            <span className="text-brand-accent">Excellence.</span>
          </h2>
          
          <div className="space-y-10">
            <div className="flex items-center gap-8 group">
              <div className="w-16 h-16 border border-white/10 flex items-center justify-center rotate-45 group-hover:border-brand-accent transition-colors">
                <Phone className="w-7 h-7 text-brand-accent -rotate-45" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-white/40 uppercase tracking-widest">Phone</span>
                <span className="text-2xl font-bold tracking-tight">416-666-8909</span>
              </div>
            </div>
            <div className="flex items-center gap-8 group">
              <div className="w-16 h-16 border border-white/10 flex items-center justify-center rotate-45 group-hover:border-brand-accent transition-colors">
                <Mail className="w-7 h-7 text-brand-accent -rotate-45" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-white/40 uppercase tracking-widest">Email</span>
                <span className="text-xl font-bold tracking-tight break-all md:break-normal">Richard@ModernTouchRenovationsInc.ca</span>
              </div>
            </div>
            <div className="flex items-center gap-8 group">
              <div className="w-16 h-16 border border-white/10 flex items-center justify-center rotate-45 group-hover:border-brand-accent transition-colors">
                <MapPin className="w-7 h-7 text-brand-accent -rotate-45" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-white/40 uppercase tracking-widest">Studio</span>
                <span className="text-lg font-bold tracking-tight leading-snug">5063 North Service Road - Suite 100,<br /> Burlington, ON</span>
              </div>
            </div>
          </div>
        </RevealOnScroll>

        <RevealOnScroll>
          <div id="estimate" className="bg-white/[0.01] border border-white/5 p-10 md:p-16 rounded-3xl shadow-2xl relative overflow-hidden backdrop-blur-sm">
            <div className="absolute top-0 right-0 p-6">
              <div className="text-[10px] uppercase tracking-[0.3em] text-brand-accent font-black">Secure Estimate Portal</div>
            </div>
            
            <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-white/40">Full Name</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-sm px-6 py-4 focus:outline-none focus:border-brand-accent transition-all text-white font-light placeholder:text-white/10" placeholder="Required" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-white/40">Email Address</label>
                  <input type="email" className="w-full bg-white/5 border border-white/10 rounded-sm px-6 py-4 focus:outline-none focus:border-brand-accent transition-all text-white font-light placeholder:text-white/10" placeholder="Required" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-white/40">Project Classification</label>
                <select className="w-full bg-white/5 border border-white/10 rounded-sm px-6 py-4 focus:outline-none focus:border-brand-accent transition-all appearance-none text-white/60 font-light">
                  <option className="bg-brand-black">Residential Renovation</option>
                  <option className="bg-brand-black">Commercial Build-out</option>
                  <option className="bg-brand-black">Mechanical & Infrastructure</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-white/40">Project Scope</label>
                <textarea rows={4} className="w-full bg-white/5 border border-white/10 rounded-sm px-6 py-4 focus:outline-none focus:border-brand-accent transition-all resize-none text-white font-light placeholder:text-white/10" placeholder="Describe the scale and objectives of your project..."></textarea>
              </div>

              <BorderBeamButton>
                Initialize Request <ArrowRight className="w-5 h-5" />
              </BorderBeamButton>
            </form>
          </div>
        </RevealOnScroll>
      </div>
    </div>
  </section>
);

const Footer = () => (
  <footer className="py-20 border-t border-white/5 px-6 bg-brand-black">
    <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-12 text-center md:text-left">
      <div className="flex flex-col items-center md:items-start gap-4">
        <div className="flex items-center gap-4 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
          <Logo className="w-10 h-10 group-hover:rotate-12 transition-transform duration-500" />
          <div className="flex flex-col">
            <span className="font-black text-lg tracking-tight uppercase italic">
              Modern Touch <span className="text-brand-accent">Renovations Inc.</span>
            </span>
            <p className="text-white/30 text-[9px] tracking-[0.2em] uppercase font-bold">
                Project Management Done Right
            </p>
          </div>
        </div>
      </div>
      
      <div className="text-white/20 text-[10px] tracking-[0.4em] uppercase font-black">
        © {new Date().getFullYear()} Burlington, ON | Richard Falle, Principal
      </div>
      
      <div className="flex gap-10 text-white/40 text-[10px] font-black uppercase tracking-[0.2em]">
        <a href="#" className="hover:text-brand-accent transition-colors">Privacy</a>
        <a href="#" className="hover:text-brand-accent transition-colors">Safety Code</a>
        <a href="#" className="hover:text-brand-accent transition-colors">Legacy</a>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <div className="bg-brand-black min-h-screen text-white selection:bg-brand-accent selection:text-brand-black">
      <Header />
      <Hero />
      <SocialProof />
      <ValueProp />
      <Services />
      <Contact />
      <Footer />
    </div>
  );
}
